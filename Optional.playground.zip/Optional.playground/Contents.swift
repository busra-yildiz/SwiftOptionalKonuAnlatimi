import UIKit

var str: String?

str = "merhaba"

if str != nil {
    print (str)
} else {
    print ("str nil değer içeriyor")
}



//unwrap işlemi
var str1: String?

str1 = "canım"

if str1 != nil {
    print (str1!)
} else {
    print ("str1 nil değer içeriyor")
}

//optional binding

if var temp = str1 {
    print (temp)
}
else {
    print ("str1 nil değer içeriyor")
}
